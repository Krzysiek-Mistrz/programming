<?php

//==============Sending Email==============
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $mailFrom = $_POST['mail'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $errorEmpty = false;
    $errorEmail = false;

    if (empty($name) || empty($mailFrom) || empty($subject) || empty($message)) {
        echo "<span class='form-error'>Uzupełnij wszystkie pola.</span>";
        $errorEmpty = true;
    }
    elseif (!filter_var($mailFrom, FILTER_VALIDATE_EMAIL)) {
        echo "<span class='form-error'>Wpisz poprawny adres email.</span>";
        $errorEmail = true;
    }
    else {
        //Nie zadziala ze zwyczajnym adresem gmail
        $mailTo = "krzysztof-jura@epistimi.net";
        $headers = "From: ".$mailFrom;
        $txt = "Otrzymales maila od: ".$name.".\n\n".$message;
        
        mail($mailTo, $subject, $txt, $headers);
        echo "<span class='form-success-h1'>Dziękuję za kontakt!</span><span class='form-success-h2'>Postaram się w niedługim czasie odpowiedzieć (z reguły do tygodnia czasu UTC+2)</span>";
    }
}
else {
    echo "<span class='form-error'>Napotkano na problem! Jeśli możesz, proszę skontaktuj się ze mną pod adresem: krzysztof.jura.official@gmail.com i daj mi o nim znać :)</span>";
}

?>

<script>
    $("#name, #mail, #subject, #message").removeClass("input-error");

    var errorEmpty = "<?php echo $errorEmpty; ?>";
    var errorEmail = "<?php echo $errorEmail; ?>";

    if (errorEmpty == true) {
        $("#name, #mail, #subject, #message").addClass("input-error");
    }
    if (errorEmail == true) {
        $("#mail").addClass("input-error");
    }
    if (errorEmpty == false && errorEmail == false) {
        $("#name, #mail, #subject, #message").val("");
    }

</script>