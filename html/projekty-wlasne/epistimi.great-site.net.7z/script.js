//===============Smooth Transition============
$(document).ready(function(){
    $("a").on('click', function(event) {
      if (this.hash !== "") {
        event.preventDefault();
        var hash = this.hash;
        $('html, body').animate({
          scrollTop: $(hash).offset().top
        }, 800, function(){
          window.location.hash = hash;
        });
      } // End if
    });
});

//===============Form Handling============
$(document).ready(function() {
    $("form").submit(function(event) {
        event.preventDefault();
        var name = $("#name").val();
        var mail = $("#mail").val();
        var subject = $("#subject").val();
        var message = $("#message").val();
        var submit = $("#submit").val();
        $("#form-message").load("contact-form.php", {
            name: name,
            mail: mail,
            subject: subject,
            message: message,
            submit: submit
        });
    });
});

//=============Sticky Nav================ 
window.onscroll = function() {myFunction()};
function myFunction() {
    var navbar = document.getElementById("header");
    var sticky = navbar.offsetTop;
    
    if (window.pageYOffset > sticky) {
        navbar.classList.remove("nonsticky");
        navbar.classList.add("sticky");
    }
    else {
        navbar.classList.remove("sticky");
        navbar.classList.add("nonsticky");
    }
}

//===============Progress Bar============
function increase1() {
    let SPEED = 40;
    let limit1 = parseInt(document.getElementById("value1").innerHTML, 10);
    for(let i = 0; i <= limit1; i++) {
        setTimeout(function () {
            document.getElementById("value1").innerHTML = i + "%";
        }, SPEED * i);
    }
}
increase1();
function increase2() {
    let SPEED = 40;
    let limit2 = parseInt(document.getElementById("value2").innerHTML, 10);
    for(let i = 0; i <= limit2; i++) {
        setTimeout(function () {
            document.getElementById("value2").innerHTML = i + "%";
        }, SPEED * i);
    }
}
increase2();
function increase3() {
    let SPEED = 40;
    let limit3 = parseInt(document.getElementById("value3").innerHTML, 10);
    for(let i = 0; i <= limit3; i++) {
        setTimeout(function () {
            document.getElementById("value3").innerHTML = i + "%";
        }, SPEED * i);
    }
}
increase3();
function increase4() {
    let SPEED = 40;
    let limit4 = parseInt(document.getElementById("value4").innerHTML, 10);
    for(let i = 0; i <= limit4; i++) {
        setTimeout(function () {
            document.getElementById("value4").innerHTML = i + "%";
        }, SPEED * i);
    }
}
increase4();